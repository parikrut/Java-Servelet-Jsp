import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Vender_Daily_Food_Entry
 */
@WebServlet("/Vender_Daily_Food_Entry")
public class Vender_Daily_Food_Entry extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Vender_Daily_Food_Entry() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 processRequest(request, response);
	        PrintWriter out = response.getWriter();
	        try
	        {
	            String f_date,f_price,f_name;
	            String vid = request.getParameter("vr_id");
	            f_name=request.getParameter("fid");
	            f_price=request.getParameter("fprice");
	            f_date=request.getParameter("fdate");
	             try
	             {
	                Class.forName("com.mysql.jdbc.Driver");
	             }
	             catch(Exception ex)
	             {
	                out.println(ex.getMessage());
	             }
	             try
	             {
	                 String url="jdbc:mysql://localhost:3306/foodtrack?zeroDateTimeBehavior=convertToNull";
	                 String un="root";
	                 String pwd="root";
	                 Connection cn;
	                 PreparedStatement pst;
	                 cn=(Connection)DriverManager.getConnection(url,un,pwd);
	                 String query1="insert into foodtrack.daily_food_entry_master_table(V_Id,foodid,foodprice,fooddate) values(?,?,?,?)";
	                 pst=(PreparedStatement)cn.prepareStatement(query1);
	                 pst.setString(1, vid);
	                 pst.setString(2, f_name);
	                 pst.setString(3, f_price);
	                 pst.setString(4, f_date);
	                 pst.executeUpdate();
	                 pst.close();
	                 cn.close();
	                 //out.println("Insert Successfully");
	                 response.sendRedirect("Vender_Home_Page.jsp");
	             }
	             catch(Exception e)
	             {
	                    out.println(e.getMessage());
	             }
	        }
	        finally
	        {
	            out.close();
	        }
	}

	 protected void processRequest(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        response.setContentType("text/html;charset=UTF-8");
	    }
}
