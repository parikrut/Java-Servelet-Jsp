import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * Servlet implementation class User_Book_Order
 */
@WebServlet("/User_Book_Order")
public class User_Book_Order extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public User_Book_Order() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		processRequest(request, response);
        PrintWriter out = response.getWriter();
        try
        {
            String f_type,f_name,f_price,quan,f_total_price;
            String tn,lf,gt,dt,ch,sn;
            String p_method,p_cardnumber,p_expdate,p_cvcode;
            
            String email=request.getParameter("eid");
            String vid = request.getParameter("vd");
            String uid = request.getParameter("ud");
            f_type=request.getParameter("ft");
            f_name=request.getParameter("fn");
            f_price=request.getParameter("fp");
            quan=request.getParameter("cart");
            f_total_price=request.getParameter("ftp");
            tn=request.getParameter("restaurantname");
            
            dt=request.getParameter("Date");
          
            
            p_method=request.getParameter("options");
            p_cardnumber=request.getParameter("cardNumber");
            p_expdate=request.getParameter("expDate");
            p_cvcode=request.getParameter("cvcode");
            
             try
             {
                Class.forName("com.mysql.jdbc.Driver");
             }
             catch(Exception ex)
             {
                out.println(ex.getMessage());
             }
             try
             {
                 String url="jdbc:mysql://localhost:3306/foodtrack?zeroDateTimeBehavior=convertToNull";
                 String un="root";
                 String pwd="root";
                 Connection cn;
                 PreparedStatement pst;
                 cn=(Connection)DriverManager.getConnection(url,un,pwd);
                 String query1="insert into foodtrack.user_book_order_table(U_Id,V_Id,foodtype,foodname,foodprice,foodquantity,food_total_price,restaurant_name,date,Status,paymentmethod,cardnumber,expdate,cvcode,commission) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                 pst=(PreparedStatement)cn.prepareStatement(query1);
                 pst.setString(1, uid);
                 pst.setString(2, vid);
                 pst.setString(3, f_type);
                 pst.setString(4, f_name);
                 pst.setString(5, f_price);
                 pst.setString(6, quan);
                 pst.setString(7, f_total_price);
                 pst.setString(8, tn);
               
                 pst.setString(9, dt);
             
                 pst.setString(10, "no");
                 pst.setString(11, p_method);
                 pst.setString(12, p_cardnumber);
                 pst.setString(13, p_expdate);
                 pst.setString(14, p_cvcode);
                 pst.setString(15, "5");
                 
                 pst.executeUpdate();
                 pst.close();
                 cn.close();
                 
                
                    String to1 = email,sub = null,msg = null;
                    sub="Order Successfully";
                    msg="Your \n\n Food Name:   "+f_name+" \n\n Food Type :  "+f_type+" \n\n Food_Total_Price : "+f_total_price;

               
                 response.sendRedirect("User_Home_Page.jsp");
             }
             catch(Exception e)
             {
                    out.println(e.getMessage());
             }
        }
        finally
        {
            out.close();
        }
	}
	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
    }

}
