

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Vender_Registration
 */
@WebServlet("/Vender_Registration")
public class Vender_Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Vender_Registration() {
        super();
        // TODO Auto-generated constructor stub
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		 processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	 protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        processRequest(request, response);
	        PrintWriter out = response.getWriter();
	        try 
	        {
	           RequestDispatcher rd = null;
	             String vtype,fn,email,pass,no,alno,state,city,station;
	             
	             vtype=request.getParameter("VenderType");
	             fn=request.getParameter("name");
	             //out.println(fn);
	             email=request.getParameter("email");
	             //out.println(email);
	             pass=request.getParameter("pw");
	             //out.println(pass);
	             no=request.getParameter("mno");
	             //out.println(no);
	             state=request.getParameter("State");
	             //out.println(state);
	             city=request.getParameter("City");
	             //out.println(city);
	             station=request.getParameter("StationName");
	            
	             try
	             {
	                Class.forName("com.mysql.jdbc.Driver");
	             }
	             catch(Exception ex)
	             {
	                out.println(ex.getMessage());
	             }
	             try
	             {
	                String url="jdbc:mysql://localhost:3306/foodtrack?zeroDateTimeBehavior=convertToNull";
	                String un="root";
	                String pa="root";
	                Connection cn;
	                StringBuilder p=new StringBuilder(pass);
	                
	                PreparedStatement pst;
	                cn=(Connection) DriverManager.getConnection(url, un, pa);
	                String query1="insert into foodtrack.register_vender(V_Type,Name,Email_Id,Password,Mobile_No,State,City,Station,Status) values(?,?,?,?,?,?,?,?,?)";
	                pst=(PreparedStatement)cn.prepareStatement(query1);
	                pst.setString(1,vtype);
	                pst.setString(2,fn);
	                pst.setString(3,email);
	                pst.setString(4,pass);
	                pst.setString(5,no);
	                pst.setString(6,state);
	                pst.setString(7,city);
	                pst.setString(8,station);
	                pst.setString(9,"no");
	                
	                pst.executeUpdate();
	                pst.close();
	                cn.close();
	                

	                rd=request.getRequestDispatcher("Login.jsp");
	                rd.forward(request, response);
	             }
	             catch(SQLException e)
	             {
	                out.println(e.getMessage()) ;
	             } 
	        } 
	        finally 
	        {            
	            out.close();
	        }
	    }
}
