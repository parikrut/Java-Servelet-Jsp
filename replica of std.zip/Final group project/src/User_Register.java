

import java.io.IOException;
import java.io.PrintWriter;
import java.security.GeneralSecurityException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class User_Register
 */
@WebServlet("/User_Register")
public class User_Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public User_Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		  processRequest(request, response);
	        PrintWriter out = response.getWriter();
	        try 
	        {
	           RequestDispatcher rd = null;
	             String fn,email,pass,no,alno,state,city;
	             
	             fn=request.getParameter("name");
	             //out.println(fn);
	             email=request.getParameter("email");
	             //out.println(email);
	             pass=request.getParameter("pw");
	             //out.println(pass);
	             no=request.getParameter("mno");
	             //out.println(no);
	             alno=request.getParameter("almno");
	             //out.println(alno);
	             state=request.getParameter("State");
	             //out.println(state);
	             city=request.getParameter("City");
	             //out.println(city);
	            
	             try
	             {
	                Class.forName("com.mysql.jdbc.Driver");
	             }
	             catch(Exception ex)
	             {
	                out.println(ex.getMessage());
	             }
	             try
	             {
	         
	                String url="jdbc:mysql://localhost:3306/foodtrack?zeroDateTimeBehavior=convertToNull";
	                String un="root";
	                String pa="root";
	                Connection cn;
	                StringBuilder p=new StringBuilder(pass);
	                
	                PreparedStatement pst;
	                cn=(Connection) DriverManager.getConnection(url, un, pa);
	                String query1="insert into foodtrack.register_user(Name,Email_Id,Password,Mobile_No,Alternate_Mobile_No,State,City,Status) values(?,?,?,?,?,?,?,?)";
	                pst=(PreparedStatement)cn.prepareStatement(query1);
	                pst.setString(1,fn);
	                pst.setString(2,email);
	                pst.setString(3,pass);
	                pst.setString(4,no);
	                pst.setString(5,alno);
	                pst.setString(6,state);
	                pst.setString(7,city);
	                pst.setString(8,"no");
	                
	                pst.executeUpdate();
	                pst.close();
	                cn.close();
	                
	             
	                String to1 = email,sub = null,msg = null;
	                sub="Food On Track Account Activation";
	                msg="Here is your Account activation link, click there and then Activate the account!";
	                msg+="<a href="+"http://localhost:8080/FoodDelivery/ActivateAccount.jsp?msg="+email+">Click here</a>";
	             
	             
	                rd=request.getRequestDispatcher("Login.jsp");
	                rd.forward(request, response);
	             }
	             catch(SQLException e)
	             {
	                out.println(e.getMessage()) ;
	             }
	        } 
	        finally 
	        {            
	            out.close();
	        }
	}
	 protected void processRequest(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        response.setContentType("text/html;charset=UTF-8");
	    }

}
