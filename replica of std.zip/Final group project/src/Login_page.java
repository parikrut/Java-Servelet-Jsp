/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author admin
 */
@WebServlet(urlPatterns = {"/Login_page"})
public class Login_page extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
   
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        String id,pwd,user,ty,path,pass,user_id,vender_id,uname,vname;
        path="Login.jsp?msg=fail";
        RequestDispatcher rd = null;
        Statement st = null;
        ResultSet rs;
        HttpSession uid=request.getSession(true);

        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            ty=request.getParameter("type");
            id=request.getParameter("email");
            pwd=request.getParameter("pw");

             try
             {
                Class.forName("com.mysql.jdbc.Driver");
             }
             catch(Exception ex)
             {
                out.println(ex.getMessage());
             }
             try
             {
                String url="jdbc:mysql://localhost:3306/foodtrack?zeroDateTimeBehavior=convertToNull";
                String ur="root";
                String pa="root";
                String status="";
                Connection cn;
                cn=(Connection) DriverManager.getConnection(url, ur, pa);
                String query=null;
                if(ty.equalsIgnoreCase("User"))
                {
                    query="select * from foodtrack.register_user where Email_Id='"+id+"'";
                    st=cn.createStatement();
                    rs=st.executeQuery(query);
                    if(rs.next())
                    {   
                            user_id=rs.getString(1);
                            uname=rs.getString(2);
                            pass=rs.getString(4);
                            status=rs.getString(9);
                            String role=rs.getString(10);
                            if(ty.equalsIgnoreCase("User") || role.equalsIgnoreCase("user"))
                            {
                                if(status.equalsIgnoreCase("no"))
                                {
                                   if(pass.equalsIgnoreCase(pwd))
                                    {
                                        uid.setAttribute("uid", user_id);
                                        uid.setAttribute("uname", uname);
                                        uid.setAttribute("email", id);
                                        System.out.println("Session Set");
                                        System.out.println(user_id);
                                        System.out.println(uname);
                                        System.out.println(id);
                                        
                                        path="User_Home_Page.jsp";
                                        
                                    }
                                   else
                                    {
                                        path="Login.jsp?msg=pwd";
                                    }
                                }
                                else
                                {
                                    path="Login.jsp?msg=req";
                                }
                            }
                            else
                            {
                        
                            }
                            st.close();
                        cn.close();
                    }
                    else
                    {
                        path="Login.jsp?msg=fail";
                    }
                }
                else if(ty.equalsIgnoreCase("Vender"))
                {
                    query="select * from foodtrack.register_vender where Email_Id='"+id+"'";
                    st=cn.createStatement();
                    rs=st.executeQuery(query);
                    if(rs.next())
                    {   
                        vender_id=rs.getString(1);
                        vname=rs.getString(3);
                        pass=rs.getString(5);
                        status=rs.getString(10);
                        if(ty.equalsIgnoreCase("Vender"))
                        {
                            if(status.equalsIgnoreCase("no"))
                            {
                                if(pass.equalsIgnoreCase(pwd))
                                    {
                                        uid.setAttribute("vid", vender_id);
                                        uid.setAttribute("vname", vname);
                                       
                                        System.out.println("Session Set");
                                        System.out.println(vender_id);
                                        System.out.println(vname);
                                        path="Vender_Home_Page.jsp";
                                    }
                                   else
                                    {
                                        path="Login.jsp?msg=pwd";
                                    }
                            }
                            else
                            {
                                path="Login.jsp?msg=req";
                            }
                        }
                        else
                        {
                            
                        }
                        st.close();
                        cn.close();
                    }
                    else
                    {
                        path="Login.jsp?msg=fail";
                    }
                }
                else if(ty.equalsIgnoreCase("Admin"))
                {
                	 
                     {
                         query="select * from foodtrack.register_user where Email_Id='"+id+"'";
                         st=cn.createStatement();
                         rs=st.executeQuery(query);
                         if(rs.next())
                         {   
                                 user_id=rs.getString(1);
                                 uname=rs.getString(2);
                                 pass=rs.getString(4);
                                 status=rs.getString(9);
                                 String role=rs.getString(10);
                                 if(ty.equalsIgnoreCase("admin") || role.equalsIgnoreCase("admin"))
                                 {
                                     if(status.equalsIgnoreCase("no"))
                                     {
                                        if(pass.equalsIgnoreCase(pwd))
                                         {
                                             uid.setAttribute("uid", user_id);
                                             uid.setAttribute("uname", uname);
                                             uid.setAttribute("email", id);
                                             System.out.println("Session Set");
                                             System.out.println(user_id);
                                             System.out.println(uname);
                                             System.out.println(id);
                                             
                                             path="Admin_Home_Page.jsp";
                                         }
                                        else
                                         {
                                             path="Login.jsp?msg=pwd";
                                         }
                                     }
                                     else
                                     {
                                         path="Login.jsp?msg=req";
                                     }
                                 }
                                 else
                                 {
                             
                                 }
                                 st.close();
                             cn.close();
                         }
                         else
                         {
                             path="Login.jsp?msg=fail";
                         }
                     }
                   
                }
                rd=request.getRequestDispatcher(path);
                rd.forward(request, response);
             }
             catch(SQLException e)
             {
                out.println(e.getMessage()) ;
             } 
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
