import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;

/**
 * Servlet implementation class Vender_Food_Entry
 */
@WebServlet("/Vender_Food_Entry")
public class Vender_Food_Entry extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Vender_Food_Entry() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out = response.getWriter();
        String f_type,f_desc,f_image,f_name;
        String vid;
        int supplierID=0;
        String ftype = null,fname = null;
        File ff = null;
        String saveFile="";  
        String rj="";       
        try
        {
            String contentType = request.getContentType();
            if((contentType != null)&&(contentType.indexOf("multipart/form-data") >= 0)){
                
            DataInputStream in = new DataInputStream(request.getInputStream());
            int formDataLength = request.getContentLength();
            byte dataBytes[] = new byte[formDataLength];
            int byteRead = 0;
            int totalBytesRead = 0;
            while(totalBytesRead < formDataLength){
            byteRead = in.read(dataBytes, totalBytesRead,formDataLength);
            totalBytesRead += byteRead;
            }
            String file = new String(dataBytes);
            saveFile = file.substring(file.indexOf("filename=\"") + 10);
            saveFile = saveFile.substring(0, saveFile.indexOf("\n"));
            saveFile = saveFile.substring(saveFile.lastIndexOf("\\") + 1,saveFile.indexOf("\""));
            int lastIndex = contentType.lastIndexOf("=");
            String boundary = contentType.substring(lastIndex + 1,contentType.length());
            int pos;
            pos = file.indexOf("filename=\"");
            pos = file.indexOf("\n", pos) + 1;
            pos = file.indexOf("\n", pos) + 1;
            pos = file.indexOf("\n", pos) + 1;
            int boundaryLocation = file.indexOf(boundary, pos) - 4;
            int startPos = ((file.substring(0, pos)).getBytes()).length;
            int endPos = ((file.substring(0, boundaryLocation)).getBytes()).length;
            ff   = new File("C:/Java Student Project/DemoTemplate/web/UploadFiles/"+saveFile);
            rj=ff.getName();
            out.println("Path : "+rj);
            FileOutputStream fileOut = new FileOutputStream(ff);
            fileOut.write(dataBytes, startPos, (endPos - startPos));
            //Part part = request.getPart("foodimage");
            fileOut.flush();
            fileOut.close();
            }   
           
            try
             {
                Class.forName("com.mysql.jdbc.Driver");
             }
             catch(Exception ex)
             {
                out.println(ex.getMessage());
             }
             try
             {
                 vid = request.getParameter("vr_id");
                 f_type=request.getParameter("foodtype");
                 f_name=request.getParameter("foodname");
                 f_desc=request.getParameter("fooddesc");
                 String url="jdbc:mysql://localhost:3306/foodtrack?zeroDateTimeBehavior=convertToNull";
                 String un="root";
                 String pwd="root";
                 Connection cn;
                 PreparedStatement pst;
                 cn=(Connection)DriverManager.getConnection(url,un,pwd);
                 String query1="insert into foodtrack.food_entry_master_table(V_Id,foodtype,foodname,fooddesc,foodimage) values(?,?,?,?,?)";
                 pst=(PreparedStatement)cn.prepareStatement(query1);
                 pst.setString(1, vid);
                 pst.setString(2, f_type);
                 pst.setString(3, f_name);
                 pst.setString(4, f_desc);
                 pst.setString(5, rj);
                 pst.executeUpdate();
                 
                 String query2="select last_insert_id() as foodid,foodtype,foodname from foodtrack.food_entry_master_table";
                 ResultSet rs=pst.executeQuery(query2);
                 
                 while (rs.next()) {
                    supplierID = rs.getInt("foodid");
                    ftype=rs.getString("foodtype");
                    fname=rs.getString("foodname");
                    System.out.println("Food Id : "+supplierID);
                }
                 pst.close();
                 cn.close();
                 StringBuffer sb = new StringBuffer("");
                 sb.append("Vender_FoodEntry_Master_Page_DemoPage.jsp");
                 sb.append("?temp=" + String.valueOf(supplierID));
                 String urlr = sb.toString();
                 String urlEncoded = response.encodeRedirectURL(urlr) ;
                 response.sendRedirect(urlEncoded);  
             }
             catch(Exception e)
             {
                    out.println(e.getMessage());
             }
    }
    finally
    {
       out.close();
    }

}
}
