

import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Vender_Food_Entry_Image
 */
@WebServlet("/Vender_Food_Entry_Image")
public class Vender_Food_Entry_Image extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Vender_Food_Entry_Image() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out = response.getWriter();
        String vid;
        int supplierID=0;
        File ff = null;
        String saveFile="";  
        String rj=""; 
        try 
        {
        String contentType = request.getContentType();
            if((contentType != null)&&(contentType.indexOf("multipart/form-data") >= 0)){
                
            DataInputStream in = new DataInputStream(request.getInputStream());
            int formDataLength = request.getContentLength();
            byte dataBytes[] = new byte[formDataLength];
            int byteRead = 0;
            int totalBytesRead = 0;
            while(totalBytesRead < formDataLength){
            byteRead = in.read(dataBytes, totalBytesRead,formDataLength);
            totalBytesRead += byteRead;
            }
            String file = new String(dataBytes);
            saveFile = file.substring(file.indexOf("filename=\"") + 10);
            saveFile = saveFile.substring(0, saveFile.indexOf("\n"));
            saveFile = saveFile.substring(saveFile.lastIndexOf("\\") + 1,saveFile.indexOf("\""));
            int lastIndex = contentType.lastIndexOf("=");
            String boundary = contentType.substring(lastIndex + 1,contentType.length());
            int pos;
            pos = file.indexOf("filename=\"");
            pos = file.indexOf("\n", pos) + 1;
            pos = file.indexOf("\n", pos) + 1;
            pos = file.indexOf("\n", pos) + 1;
            int boundaryLocation = file.indexOf(boundary, pos) - 4;
            int startPos = ((file.substring(0, pos)).getBytes()).length;
            int endPos = ((file.substring(0, boundaryLocation)).getBytes()).length;
            ff   = new File("F:/EclipesWorkspace/DemoTemplate/WebContent/UploadFiles"+saveFile);
            rj=ff.getName();
            out.println("Path : "+rj);
            FileOutputStream fileOut = new FileOutputStream(ff);
            fileOut.write(dataBytes, startPos, (endPos - startPos));
            //Part part = request.getPart("foodimage");
            fileOut.flush();
            fileOut.close();
            } 
        
            String foodid=request.getParameter("fid");
            String path;
            
            RequestDispatcher rd = null;
            try
             {
                Class.forName("com.mysql.jdbc.Driver");
             }
             catch(Exception ex)
             {
                out.println(ex.getMessage());
             }
             try
             {
                String url="jdbc:mysql://localhost:3306/foodtrack?zeroDateTimeBehavior=convertToNull";
                String ur="root";
                String pa="root";
                Connection cn;
                cn=(Connection) DriverManager.getConnection(url, ur, pa);
                Statement st=cn.createStatement();
                 
                String query="update foodtrack.food_entry_master_table set foodimage='"+rj+"' where foodid='"+foodid+"'";
                    st.executeUpdate(query);

                    out.println("Update Succeessfully");
                    
                    st.close();
                    cn.close();
                    
                    path="Vender_Home_Page.jsp";

                    rd=request.getRequestDispatcher(path);
                    rd.forward(request, response);
             }
             catch(SQLException e)
             {
                out.println(e.getMessage()) ;
             }
        }
    finally
    {
       out.close();
    }
    }

}
