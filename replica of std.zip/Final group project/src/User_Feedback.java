import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class User_Feedback
 */
@WebServlet("/User_Feedback")
public class User_Feedback extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public User_Feedback() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		 processRequest(request, response);
	        PrintWriter out = response.getWriter();
	        try
	        {
	            String name,email,mobilenumber,f_msg,f_date;
	            String uid = request.getParameter("Us_id");
	            name=request.getParameter("name");
	            email=request.getParameter("email");
	            mobilenumber=request.getParameter("MobileNumber");
	            f_msg=request.getParameter("msg");
	            f_date=request.getParameter("dt");

	            try
	             {
	                Class.forName("com.mysql.jdbc.Driver");
	             }
	             catch(Exception ex)
	             {
	                out.println(ex.getMessage());
	             }
	             try
	             {
	                 String url="jdbc:mysql://localhost:3306/foodtrack?zeroDateTimeBehavior=convertToNull";
	                 String un="root";
	                 String pwd="root";
	                 Connection cn;
	                 PreparedStatement pst;
	                 cn=(Connection)DriverManager.getConnection(url,un,pwd);
	                 String query1="insert into foodtrack.user_feedback_table(U_Id,Name,Email_Id,Mobile_No,Feedback_Msg,Feedback_Date) values(?,?,?,?,?,?)";
	                 pst=(PreparedStatement)cn.prepareStatement(query1);
	                 pst.setString(1, uid);
	                 pst.setString(2, name);
	                 pst.setString(3, email);
	                 pst.setString(4, mobilenumber);
	                 pst.setString(5, f_msg);
	                 pst.setString(6, f_date);
	                 
	                 pst.executeUpdate();
	                 pst.close();
	                 cn.close();
	                 //out.println("Insert Successfully");
	                 response.sendRedirect("User_Home_Page.jsp");
	             }
	             catch(Exception e)
	             {
	                    out.println(e.getMessage());
	             }
	        }
	        finally
	        {
	            out.close();
	        }
	}

	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
    }
}
