

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class Contact_Us_Servlet
 */
@WebServlet("/Contact_Us_Servlet")
public class Contact_Us_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Contact_Us_Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        processRequest(request, response);
        PrintWriter out = response.getWriter();
        try
        {
            String name,email,msg;
            name=request.getParameter("name");
            email=request.getParameter("email");
            msg=request.getParameter("message");
            
            try
             {
                Class.forName("com.mysql.jdbc.Driver");
             }
             catch(Exception ex)
             {
                out.println(ex.getMessage());
             }
             try
             {
                 String url="jdbc:mysql://localhost:3306/foodtrack?zeroDateTimeBehavior=convertToNull";
                 String un="root";
                 String pwd="root";
                 Connection cn;
                 PreparedStatement pst;
                 cn=(Connection)DriverManager.getConnection(url,un,pwd);
                 String query1="insert into foodtrack.user_contact_table(Name,Email_Id,Msg) values(?,?,?)";
                 pst=(PreparedStatement)cn.prepareStatement(query1);
                 pst.setString(1, name);
                 pst.setString(2, email);
                 pst.setString(3, msg);
                 
                 pst.executeUpdate();
                 pst.close();
                 cn.close();
                 //out.println("Insert Successfully");
                 
                
                String to1 = email,sub = null,msg1 = null;
                sub="Food On Track";
                msg1="Your \n\n Name:   "+name+" \n\n Email Id :  "+email+" \n\n Message : "+msg;

             
                 
                response.sendRedirect("MainPage.jsp");
             }
             catch(Exception e)
             {
                    out.println(e.getMessage());
             }
        }
        finally
        {
            out.close();
        }
        
    }
	public String getServletInfo() {
        return "Short description";
    }
}
