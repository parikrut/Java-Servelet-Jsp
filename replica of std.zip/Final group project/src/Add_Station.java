import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class Add_Station
 */
@WebServlet("/Add_Station")
public class Add_Station extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Add_Station() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		 processRequest(request, response);
	        PrintWriter out = response.getWriter();
	        try
	        {
	            RequestDispatcher rd = null;
	            String stiname,sid;
	            stiname=request.getParameter("stname");
	            sid=request.getParameter("s_id");
	             try
	             {
	                Class.forName("com.mysql.jdbc.Driver");
	             }
	             catch(Exception ex)
	             {
	                out.println(ex.getMessage());
	             }
	             try
	             {
	                 String url="jdbc:mysql://localhost:3306/foodtrack?zeroDateTimeBehavior=convertToNull";
	                 String un="root";
	                 String pwd="root";
	                 Connection cn;
	                 PreparedStatement pst;
	                 cn=(Connection)DriverManager.getConnection(url,un,pwd);
	                 String query1="insert into foodtrack.restaurant_table(city_table_cityid,restaurant_name) values(?,?)";
	                 pst=(PreparedStatement)cn.prepareStatement(query1);
	                 pst.setString(1, sid);
	                 pst.setString(2, stiname);
	                 pst.executeUpdate();
	                 pst.close();
	                 cn.close();
	                 rd=request.getRequestDispatcher("Admin_Home_Page.jsp");
	                 rd.forward(request, response);
	             }
	             catch(Exception e)
	             {
	                    out.println(e.getMessage());
	             }
	        }
	        finally
	        {
	            out.close();
	        }
	}
	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
    }

}
